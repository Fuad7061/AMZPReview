<?php
/**
 * Side-by-side comparison table.
 * Expects: yf_products (array), yf_post_id (int)
 */
$products = get_query_var( 'yf_products' );
$post_id  = (int) get_query_var( 'yf_post_id' );
if ( empty( $products ) ) return;
$slug = get_post_field( 'post_name', $post_id );
?>
<section class="yf-compare">
	<h2 class="yf-section-title">At a glance</h2>
	<div class="yf-compare__scroll">
		<table class="yf-compare__table">
			<thead>
				<tr>
					<th>#</th>
					<th>Product</th>
					<th>Rating</th>
					<th>Price</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $products as $p ) : ?>
					<tr>
						<td>#<?php echo (int) $p['rank']; ?></td>
						<td>
							<a href="#rank-<?php echo (int) $p['rank']; ?>">
								<?php echo esc_html( wp_trim_words( $p['title'], 8 ) ); ?>
							</a>
						</td>
						<td><?php echo ! empty( $p['rating'] ) ? esc_html( number_format( (float) $p['rating'], 1 ) ) : '—'; ?></td>
						<td><?php echo ! empty( $p['price'] ) ? esc_html( function_exists( 'pr_price_display' ) ? pr_price_display( $p['price'] ) : yadfood_format_price( $p['price'] ) ) : '—'; ?></td>
						<td>
							<?php $url = yadfood_amazon_url( $p['asin'], $slug ); if ( $url ) : ?>
								<a class="yf-cta yf-cta--sm" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="nofollow sponsored noopener">View</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</section>
