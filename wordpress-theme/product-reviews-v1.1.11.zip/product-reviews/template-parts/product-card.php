<?php
/**
 * Product card template part.
 * Expects: yf_product (array), yf_post_id (int)
 */
$p       = get_query_var( 'yf_product' );
$post_id = (int) get_query_var( 'yf_post_id' );
if ( empty( $p ) || empty( $p['title'] ) ) return;

$slug   = get_post_field( 'post_name', $post_id );
$buyurl = yadfood_amazon_url( $p['asin'], $slug );

$badge_map = array(
	'editors_choice' => "Editor's Choice",
	'best_value'     => 'Best Value',
	'premium'        => 'Premium Pick',
	'budget'         => 'Best Budget',
);
?>
<article class="yf-product" id="rank-<?php echo (int) $p['rank']; ?>">
	<div class="yf-product__rank">#<?php echo (int) $p['rank']; ?></div>

	<?php if ( ! empty( $p['badge'] ) && isset( $badge_map[ $p['badge'] ] ) ) : ?>
		<div class="yf-ribbon"><?php echo esc_html( $badge_map[ $p['badge'] ] ); ?></div>
	<?php endif; ?>

	<?php if ( function_exists( 'pr_render_deal_ribbon' ) ) {
		echo pr_render_deal_ribbon( $p ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} ?>

	<?php if ( function_exists( 'pr_render_score_breakdown' ) ) {
		echo pr_render_score_breakdown( $p ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} ?>

	<?php if ( ! empty( $p['image'] ) ) : ?>
		<div class="yf-product__img">
			<?php
			$is_first = ( 1 === (int) $p['rank'] );
			echo function_exists( 'pr_render_remote_image' )
				? pr_render_remote_image( $p['image'], $p['title'], array(
					'class' => 'yf-product__image',
					'eager' => $is_first,
				) )
				: '<img src="' . esc_url( $p['image'] ) . '" alt="' . esc_attr( $p['title'] ) . '" loading="lazy" decoding="async">';
			?>
		</div>
	<?php endif; ?>

	<div class="yf-product__body">
		<h3 class="yf-product__title"><?php echo esc_html( $p['title'] ); ?></h3>

		<div class="yf-product__meta">
			<?php if ( ! empty( $p['rating'] ) ) : ?>
				<?php echo yadfood_render_stars( $p['rating'] ); ?>
				<span class="yf-product__rating"><?php echo esc_html( number_format( (float) $p['rating'], 1 ) ); ?></span>
				<?php if ( ! empty( $p['review_count'] ) ) : ?>
					<span class="yf-product__reviews">(<?php echo esc_html( number_format_i18n( $p['review_count'] ) ); ?>)</span>
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( ! empty( $p['price'] ) ) :
				$price_fmt = function_exists( 'pr_price_display' ) ? pr_price_display( $p['price'] ) : ( function_exists( 'pr_format_price_localized' ) ? pr_format_price_localized( $p['price'] ) : yadfood_format_price( $p['price'] ) );
			?>
				<span class="yf-product__price"><?php echo esc_html( $price_fmt ); ?></span>
			<?php endif; ?>
		</div>

		<?php if ( function_exists( 'pr_render_amazon_badges' ) ) {
			echo pr_render_amazon_badges( $p ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} ?>

		<?php if ( function_exists( 'pr_render_price_sparkline' ) && ! empty( $p['asin'] ) ) {
			$spark = pr_render_price_sparkline( $p['asin'], 30 );
			if ( $spark ) {
				echo '<div class="yf-product__spark" aria-hidden="false">' . $spark . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		} ?>

		<?php if ( function_exists( 'pr_render_variations' ) ) {
			echo pr_render_variations( $p, $slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} ?>

		<?php if ( ! empty( $p['why'] ) ) : ?>
			<p class="yf-product__why"><?php echo esc_html( $p['why'] ); ?></p>
		<?php endif; ?>

		<?php if ( ! empty( $p['pros'] ) || ! empty( $p['cons'] ) ) : ?>
			<div class="yf-proscons">
				<div class="yf-proscons__col yf-proscons__col--pros">
					<h4>Pros</h4>
					<ul><?php foreach ( (array) $p['pros'] as $pro ) : ?><li><?php echo esc_html( $pro ); ?></li><?php endforeach; ?></ul>
				</div>
				<div class="yf-proscons__col yf-proscons__col--cons">
					<h4>Cons</h4>
					<ul><?php foreach ( (array) $p['cons'] as $con ) : ?><li><?php echo esc_html( $con ); ?></li><?php endforeach; ?></ul>
				</div>
			</div>
		<?php endif; ?>

		<?php if ( $buyurl ) : ?>
			<a class="yf-cta" href="<?php echo esc_url( $buyurl ); ?>" target="_blank" rel="nofollow sponsored noopener" data-asin="<?php echo esc_attr( $p['asin'] ); ?>" data-slug="<?php echo esc_attr( $slug ); ?>">
				Check price on Amazon →
			</a>
		<?php endif; ?>

		<?php if ( function_exists( 'pr_render_bundle' ) ) {
			echo pr_render_bundle( $p, $slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} ?>
	</div>
</article>
