<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="yf-skip" href="#yf-main"><?php esc_html_e( 'Skip to content', 'product-reviews' ); ?></a>

<header class="yf-header" role="banner">
	<div class="yf-container yf-header__inner">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="yf-logo">
			<?php
			$pr_logo = pr_logo_url();
			if ( $pr_logo ) {
				echo '<img src="' . esc_url( $pr_logo ) . '" alt="' . esc_attr( pr_brand() ) . '" class="yf-logo__img">';
			} elseif ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				$initials = strtoupper( mb_substr( pr_short_name(), 0, 2 ) );
				echo '<span class="yf-logo__mark">' . esc_html( $initials ) . '</span><span class="yf-logo__text">' . esc_html( pr_short_name() ) . '</span>';
			}
			?>
		</a>

		<nav class="yf-nav" aria-label="<?php esc_attr_e( 'Primary', 'product-reviews' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'yf-nav__list',
				'fallback_cb'    => function () {
					echo '<ul class="yf-nav__list">';
					echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Home</a></li>';
					$reviews_url = get_post_type_archive_link( 'review' );
					$reviews_url = is_string( $reviews_url ) && '' !== $reviews_url ? $reviews_url : home_url( '/' );
					echo '<li><a href="' . esc_url( $reviews_url ) . '">Reviews</a></li>';
					echo '</ul>';
				},
			) );
			?>
		</nav>

		<form class="yf-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label for="yf-search-input" class="screen-reader-text">Search</label>
			<input id="yf-search-input" type="search" name="s" placeholder="Search reviews…" value="<?php echo esc_attr( get_search_query() ); ?>">
			<button type="submit" aria-label="Search">🔍</button>
		</form>
	</div>
</header>

<main id="yf-main" class="yf-main" role="main">
