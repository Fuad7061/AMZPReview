/* Frontend sprinkles: click tracking + smooth TOC + sticky CTA on mobile. */
(function () {
	"use strict";

	// Track CTA clicks (best-effort, non-blocking).
	document.addEventListener("click", function (e) {
		var el = e.target.closest(".yf-cta[data-asin]");
		if (!el) return;
		try {
			var data = { asin: el.dataset.asin || "", slug: el.dataset.slug || "" };
			navigator.sendBeacon &&
				navigator.sendBeacon(
					(window.YadFood && YadFood.restUrl ? YadFood.restUrl : "/wp-json/yadfood/v1/") + "click",
					new Blob([JSON.stringify(data)], { type: "application/json" })
				);
		} catch (err) {}
	});

	// TOC active link highlight.
	var tocLinks = document.querySelectorAll(".yf-toc a[href^='#']");
	if (tocLinks.length && "IntersectionObserver" in window) {
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					tocLinks.forEach(function (a) {
						a.classList.toggle("is-active", a.getAttribute("href") === "#" + entry.target.id);
					});
				}
			});
		}, { rootMargin: "-40% 0px -55% 0px" });
		document.querySelectorAll(".yf-review__main [id]").forEach(function (s) { io.observe(s); });
	}
})();
