</main>

<footer class="yf-footer" role="contentinfo">
	<div class="yf-container yf-footer__inner">
		<div class="yf-footer__brand">
			<strong><?php echo esc_html( pr_brand() ); ?></strong>
			<p><?php echo esc_html( pr_tagline() ); ?></p>
		</div>

		<nav class="yf-footer__nav" aria-label="<?php esc_attr_e( 'Footer', 'product-reviews' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'footer',
				'container'      => false,
				'menu_class'     => 'yf-footer__list',
				'fallback_cb'    => '__return_empty_string',
			) );
			?>
		</nav>

		<div class="yf-footer__disclosure">
			<?php echo wp_kses_post( get_option( 'yadfood_disclosure', get_theme_mod( 'yadfood_disclosure', '' ) ) ); ?>
		</div>

		<div class="yf-footer__copy">
			<?php echo esc_html( pr_footer_copyright() ); ?>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
